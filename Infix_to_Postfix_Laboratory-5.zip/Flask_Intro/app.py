

# --- INFIX TO POSTFIX FUNCTION (LAB 5) ---
def infix_to_postfix(expression):
    precedence = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3}
    stack = []
    output = []

    def is_operand(ch):
        return ch.isalnum()

    for token in expression.replace(" ", ""):
        if is_operand(token):
            output.append(token)
        elif token == '(':
            stack.append(token)
        elif token == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            if stack:
                stack.pop()
        else:
            while stack and stack[-1] != '(' and precedence.get(stack[-1], 0) >= precedence.get(token, 0):
                output.append(stack.pop())
            stack.append(token)

    while stack:
        output.append(stack.pop())

    return " ".join(output)


# --- ROUTE FOR INFIX TO POSTFIX PAGE ---
from flask import request, render_template

@app.route("/infix_to_postfix", methods=["GET", "POST"])
def infix_converter():
    result = None
    if request.method == "POST":
        expression = request.form.get("expression", "")
        result = infix_to_postfix(expression)
    return render_template("infix_to_postfix.html", result=result)
